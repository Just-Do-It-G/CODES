#include "vex.h"

void infoScreen(bool motorTemps, bool ) {

}
