#include "vex.h"

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Rfront               motor         10              
// Rmiddle              motor         9               
// Rback                motor         20              
// Lfront               motor         3               
// Lmiddle              motor         2               
// Lback                motor         11              
// intake               motor         1               
// Controller1          controller                    
// LwingBack            digital_out   A               
// RwingBack            digital_out   B               
// ---- END VEXCODE CONFIGURED DEVICES ----

using namespace vex;
competition Competition;


Drive chassis(
  
ZERO_TRACKER_ODOM, 
motor_group(Lfront,Lmiddle,Lback), 
motor_group(Rfront,Rmiddle,Rback), 
PORT20, 
2.75, 
1, 
360,

//LF:      //RF:    
PORT1,     -PORT2,

//LB:      //RB: 
PORT3,     -PORT4,

//Forward Tracker port
3,

//Forward Tracker diameter
2.75,

//Forward Tracker center distance (a positive distance corresponds to a tracker on the right side of the robot, negative is left.)
-2,

//Sideways Tracker Port
1,

//Sideways tracker diameter
-2.75,

//Sideways tracker center distance (positive distance is behind the center of the robot, negative is in front):
5.5

);

int current_auton_selection = 0;
bool auto_started = false;

void pre_auton(void) {
  vexcodeInit();
  default_constants();

  while(auto_started == false){
    Brain.Screen.clearScreen();
    switch(current_auton_selection){
      case 0:
        Brain.Screen.printAt(50, 50, "Drive Test");
        break;
      case 1:
        Brain.Screen.printAt(50, 50, "Drive Test");
        break;
      case 2:
        Brain.Screen.printAt(50, 50, "Turn Test");
        break;
      case 3:
        Brain.Screen.printAt(50, 50, "Swing Test");
        break;
      case 4:
        Brain.Screen.printAt(50, 50, "Full Test");
        break;
      case 5:
        Brain.Screen.printAt(50, 50, "Odom Test");
        break;
      case 6:
        Brain.Screen.printAt(50, 50, "Tank Odom Test");
        break;
      case 7:
        Brain.Screen.printAt(50, 50, "Holonomic Odom Test");
        break;
    }
    if(Brain.Screen.pressing()){
      while(Brain.Screen.pressing()) {}
      current_auton_selection ++;
    } else if (current_auton_selection == 8){
      current_auton_selection = 0;
    }
    task::sleep(10);
  }
}

void autonomous(void) {
  auto_started = true;
  switch(current_auton_selection){  
    case 0:
      drive_test();
      break;
    case 1:
      drive_test();
      break;
    case 2:
      turn_test();
      break;
    case 3:
      swing_test();
      break;
    case 4:
      full_test();
      break;
    case 5:
      odom_test();
      break;
    case 6:
      tank_odom_test();
      break;
    case 7:
      holonomic_odom_test();
      break;
 }
}

//User control starts here

bool shift (false);

bool frontRightWing(false);
bool frontRightWingPressed(false);

bool frontLeftWing(false);
bool frontLeftWingPressed(false);

bool backRightWing(false);
bool backRightWingPressed(false);

bool backLeftWing(false);
bool backLeftWingPressed(false);

void usercontrol(void) {
  
  while (1) {
    //Updates user control variables

      //We use a shift key to give the driver more control over the robot and allow one button to perform multiple functions
      //Updates the state of "shift"
      if (Controller1.ButtonL2.pressing()) {
        shift = true;
      }
      else if (!Controller1.ButtonL2.pressing()) {
        shift = false;
      }

      //Updates the state of variables used for toggles
      if (!Controller1.ButtonX.pressing()) {
        frontRightWingPressed = false;
      }
      if (!Controller1.ButtonB.pressing()) {
        backRightWingPressed = false;
      }
      if (!Controller1.ButtonUp.pressing()) {
        frontLeftWingPressed = false;
      }
      if (!Controller1.ButtonDown.pressing()) {
        backLeftWingPressed = false;
      } 

    //Calls a function to update motor power depending on the controller stick positions
      chassis.control_arcade();

    //Checks if the robot should be running the intake and the direction it should run
    if (Controller1.ButtonR2.pressing()) {
      if (shift) {
        intake.spin(vex::reverse, 12, volt);
      }
      else if (!shift) {
        intake.spin(vex::forward, 12, volt);
      }
    }
    else if (!Controller1.ButtonR2.pressing()) {
      intake.stop(brake);
    }

    //Updates the variables for the wings based on controller input
    if (Controller1.ButtonX.pressing() && frontRightWingPressed == false) {
      frontRightWing = !frontRightWing;
      frontRightWingPressed = true;
    }
    if (Controller1.ButtonB.pressing() && backRightWingPressed == false) {
      backRightWing = !backRightWing;
      backRightWingPressed = true;
    }
    if (Controller1.ButtonUp.pressing() && frontLeftWingPressed == false) {
      frontLeftWing = !frontLeftWing;
      frontLeftWingPressed = true;
    }
    if (Controller1.ButtonDown.pressing() && backLeftWingPressed == false) {
      backLeftWing = !backLeftWing;
      backLeftWingPressed = true;
    }

    //Updates soleniods for the robot systems based on previosly set variables
    LwingBack.set(backLeftWing);
    RwingBack.set(backRightWing);


    wait(20, msec);
  }
}


int main() {
  // Set up callbacks for autonomous and driver control periods
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  
  // Run the pre-autonomous function
  pre_auton();

  // Prevent main from exiting with an infinite loop
  while (true) {
    wait(100, msec);
  }
}
