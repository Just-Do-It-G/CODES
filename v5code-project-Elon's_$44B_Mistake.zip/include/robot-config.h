using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor Rfront;
extern motor Rmiddle;
extern motor Rback;
extern motor Lfront;
extern motor Lmiddle;
extern motor Lback;
extern motor intake;
extern controller Controller1;
extern digital_out LwingBack;
extern digital_out RwingBack;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );